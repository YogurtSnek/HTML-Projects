window.alert("You are entering my website, I hope it is to your liking");
document.getElementById("Des").innerHTML = "The Solar System is the gravitationally bound system of the Sun and the objects that orbit it.";
document.writeln("<ul>"
+"\n<li>The Solar System has Eight Planets</li>"
+"\n<li>The Solar System has been around for billions of years</li>"
+"\n<li>The Sun is 93 million miles away from us</li>"
+"\n</ul>");

console.log("And did you know... Venus can be seen from earth");